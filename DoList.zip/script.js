// 获取DOM元素
const todoInput = document.getElementById('todoInput');
const todoList = document.getElementById('todoList');
const bgUpload = document.getElementById('bgUpload');
const todoContainer = document.querySelector('.todo-container');
const container = document.querySelector('.container');

// 从 Chrome 存储加载数据
let todos = [];
let backgroundImage = '';
let containerPosition = { x: 20, y: 20 };

// 加载数据
chrome.storage.local.get(['todos', 'backgroundImage', 'containerPosition'], (result) => {
    todos = result.todos || [];
    backgroundImage = result.backgroundImage || '';
    containerPosition = result.containerPosition || { x: 20, y: 20 };
    
    if (backgroundImage) {
        setBackground(backgroundImage);
    }
    setContainerPosition(containerPosition.x, containerPosition.y);
    renderTodos();
});

// 设置容器位置
function setContainerPosition(x, y) {
    todoContainer.style.left = x + 'px';
    todoContainer.style.top = y + 'px';
    chrome.storage.local.set({ containerPosition: { x, y } });
}

// 设置背景图片
function setBackground(imageUrl) {
    todoContainer.style.backgroundImage = `url(${imageUrl})`;
    chrome.storage.local.set({ backgroundImage: imageUrl });
}

// 渲染待办事项列表
function renderTodos() {
    todoList.innerHTML = '';
    todos.forEach((todo, index) => {
        const li = document.createElement('li');
        li.className = `todo-item ${todo.completed ? 'completed' : ''}`;
        li.innerHTML = `
            <input type="checkbox" ${todo.completed ? 'checked' : ''}>
            <span>${todo.text}</span>
        `;

        // 复选框事件
        const checkbox = li.querySelector('input[type="checkbox"]');
        checkbox.addEventListener('change', () => {
            todos[index].completed = checkbox.checked;
            chrome.storage.local.set({ todos });
            renderTodos();
        });

        // 添加鼠标悬停和键盘事件监听
        let isHovered = false;
        
        li.addEventListener('mouseenter', () => {
            isHovered = true;
            li.classList.add('hover');
        });

        li.addEventListener('mouseleave', () => {
            isHovered = false;
            li.classList.remove('hover');
        });

        // 全局键盘事件监听
        document.addEventListener('keydown', (e) => {
            if (isHovered && (e.key === 'Backspace' || e.key === 'Delete')) {
                todos.splice(index, 1);
                chrome.storage.local.set({ todos });
                renderTodos();
            }
        });

        todoList.appendChild(li);
    });
}

// 添加待办事项
function addTodo() {
    const text = todoInput.value.trim();
    if (text) {
        todos.push({ text, completed: false });
        chrome.storage.local.set({ todos });
        todoInput.value = '';
        renderTodos();
    }
}

// 事件监听器
todoInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        addTodo();
    }
});

// 背景图片上传
bgUpload.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            setBackground(e.target.result);
        };
        reader.readAsDataURL(file);
    }
});

// 拖拽功能
let isDragging = false;
let currentX;
let currentY;
let initialX;
let initialY;
let xOffset = containerPosition.x;
let yOffset = containerPosition.y;

container.addEventListener('mousedown', dragStart);
document.addEventListener('mousemove', drag);
document.addEventListener('mouseup', dragEnd);

function dragStart(e) {
    // 如果点击的是调整大小的区域，不启动拖拽
    if (e.target === todoContainer && 
        e.clientX > todoContainer.offsetWidth - 15 && 
        e.clientY > todoContainer.offsetHeight - 15) {
        return;
    }

    // 如果点击的是输入框或按钮，不启动拖拽
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'BUTTON') {
        return;
    }

    initialX = e.clientX - xOffset;
    initialY = e.clientY - yOffset;

    isDragging = true;
    container.classList.add('dragging');
}

function drag(e) {
    if (isDragging) {
        e.preventDefault();
        currentX = e.clientX - initialX;
        currentY = e.clientY - initialY;

        xOffset = currentX;
        yOffset = currentY;

        setContainerPosition(currentX, currentY);
    }
}

function dragEnd() {
    initialX = currentX;
    initialY = currentY;
    isDragging = false;
    container.classList.remove('dragging');
}

// 初始渲染
renderTodos(); 