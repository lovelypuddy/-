const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

const sizes = [16, 48, 128];
const inputFile = path.join(__dirname, 'icons', 'icon.svg');
const outputDir = path.join(__dirname, 'icons');

sizes.forEach(size => {
    sharp(inputFile)
        .resize(size, size)
        .png()
        .toFile(path.join(outputDir, `icon${size}.png`))
        .then(() => console.log(`Created ${size}x${size} icon`))
        .catch(err => console.error(`Error creating ${size}x${size} icon:`, err));
}); 