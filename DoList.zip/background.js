chrome.action.onClicked.addListener(() => {
    // 查找已存在的待办事项窗口
    chrome.windows.getAll({ populate: true }, (windows) => {
        const todoWindow = windows.find(window => 
            window.tabs && window.tabs[0] && window.tabs[0].url.includes('index.html')
        );

        if (todoWindow) {
            // 如果窗口存在，激活它
            chrome.windows.update(todoWindow.id, { focused: true });
        } else {
            // 如果窗口不存在，创建新窗口
            chrome.windows.create({
                url: 'index.html',
                type: 'popup',
                width: 400,
                height: 300,
                left: 100,
                top: 100
            });
        }
    });
}); 